//
//  ContentView.swift
//  SwiftUITutorial
//
//  Created by Владислав  on 30.07.2024.
//

import SwiftUI


struct ContentView: View {
    var body: some View {
        Form {
            Section(header: Text("Section 1")) {
                Text("Element of Section 1 num 1")
                Text("Element of Section 1 num 2")
                }
            Section(header: Text("Section 2")) {
                Text("Element of Section 2 num 1")
                Text("Element of Section 2 num 2")

            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
